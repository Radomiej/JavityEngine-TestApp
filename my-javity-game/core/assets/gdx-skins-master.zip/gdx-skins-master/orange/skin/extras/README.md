This folder contains additional skins based on the *Orange Peel UI* used by the [Skin Composer](https://github.com/raeleus/skin-composer) application.
